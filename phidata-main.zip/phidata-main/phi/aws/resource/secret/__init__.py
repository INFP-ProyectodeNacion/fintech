from phi.aws.resource.secret.manager import SecretsManager
from phi.aws.resource.secret.reader import read_secrets
